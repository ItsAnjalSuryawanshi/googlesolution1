import Link from "next/link"
import { ArrowRight, Activity, Shield, Brain, Utensils, Calendar, MessageSquare, BarChart2, Cloud } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="mr-4 flex">
            <Link href="/" className="flex items-center space-x-2">
              <Activity className="h-6 w-6 text-primary" />
              <span className="font-bold">VayuVenture</span>
            </Link>
          </div>
          <nav className="flex flex-1 items-center justify-end space-x-4">
            <Link href="/features" className="text-sm font-medium">
              Features
            </Link>
            <Link href="/about" className="text-sm font-medium">
              About
            </Link>
            <Link href="/contact" className="text-sm font-medium">
              Contact
            </Link>
            <Button asChild size="sm">
              <Link href="/login">Login</Link>
            </Button>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="space-y-4">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  AI-Driven Athlete Management System
                </h1>
                <p className="max-w-[600px] text-muted-foreground md:text-xl">
                  VayuVenture provides smarter and better ways to track performance, prevent injuries for athletes and
                  coaches. Bridge the gap between performance analytics and real-world training.
                </p>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button>
                    Get Started
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                  <Button variant="outline">Learn More</Button>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <div className="relative h-[350px] w-[350px] rounded-lg bg-muted p-2">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Activity className="h-32 w-32 text-primary opacity-20" />
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-xl font-bold">Performance Analytics Dashboard</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Features</h2>
              <p className="max-w-[85%] text-muted-foreground md:text-xl">
                Our comprehensive suite of tools to enhance athlete performance and well-being
              </p>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader>
                  <Activity className="h-6 w-6 text-primary" />
                  <CardTitle className="mt-2">Performance Tracking</CardTitle>
                  <CardDescription>Real-time monitoring of speed, endurance, strength, & recovery</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader>
                  <Shield className="h-6 w-6 text-primary" />
                  <CardTitle className="mt-2">Injury Prevention</CardTitle>
                  <CardDescription>Analytics to identify injury risks before they happen</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader>
                  <Brain className="h-6 w-6 text-primary" />
                  <CardTitle className="mt-2">AI-Driven Insights</CardTitle>
                  <CardDescription>Adaptive AI-generated workout plans tailored to athlete progress</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader>
                  <Utensils className="h-6 w-6 text-primary" />
                  <CardTitle className="mt-2">Nutrition Planning</CardTitle>
                  <CardDescription>Personalized diet recommendations based on training goals</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader>
                  <Calendar className="h-6 w-6 text-primary" />
                  <CardTitle className="mt-2">Contest Creation</CardTitle>
                  <CardDescription>Dashboard for organizers from state to national level</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader>
                  <MessageSquare className="h-6 w-6 text-primary" />
                  <CardTitle className="mt-2">Communication Portal</CardTitle>
                  <CardDescription>Seamless in-app messaging & video calls for feedback</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader>
                  <BarChart2 className="h-6 w-6 text-primary" />
                  <CardTitle className="mt-2">Data Visualization</CardTitle>
                  <CardDescription>Interactive graphs & AI-powered performance insights</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader>
                  <Cloud className="h-6 w-6 text-primary" />
                  <CardTitle className="mt-2">Cloud Platform</CardTitle>
                  <CardDescription>Secure & centralized storage for all athlete data & reports</CardDescription>
                </CardHeader>
              </Card>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-24 md:flex-row">
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            © 2024 VayuVenture. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground underline-offset-4 hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground underline-offset-4 hover:underline">
              Privacy
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

