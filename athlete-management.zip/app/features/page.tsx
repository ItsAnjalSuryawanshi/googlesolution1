import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Activity, Shield, Brain, Utensils, Calendar, MessageSquare, BarChart2, Cloud } from "lucide-react"

export default function FeaturesPage() {
  const features = [
    {
      icon: <Activity className="h-12 w-12 text-primary" />,
      title: "Performance Tracking & AI-Driven Analytics",
      description:
        "Real-time monitoring of speed, endurance, strength, & recovery metrics. Our AI analyzes your performance data to provide actionable insights.",
    },
    {
      icon: <Shield className="h-12 w-12 text-primary" />,
      title: "Injury Prevention & Recovery Management",
      description:
        "Advanced analytics to identify injury risks before they happen. Personalized recovery plans to help you get back to peak performance safely.",
    },
    {
      icon: <Brain className="h-12 w-12 text-primary" />,
      title: "Personalized Training Programs",
      description:
        "Adaptive AI-generated workout plans tailored to your specific goals and progress. Adjusts in real-time based on your performance data.",
    },
    {
      icon: <Utensils className="h-12 w-12 text-primary" />,
      title: "Nutrition & Diet Recommendations",
      description:
        "Personalized diet recommendations based on your training goals, body composition, and nutritional needs. Meal planning and tracking.",
    },
    {
      icon: <Calendar className="h-12 w-12 text-primary" />,
      title: "Contest Creation Dashboard",
      description:
        "Comprehensive tools for event organizers from local to national level. Manage registrations, schedules, and results all in one place.",
    },
    {
      icon: <MessageSquare className="h-12 w-12 text-primary" />,
      title: "Coach-Athlete Communication Portal",
      description:
        "Seamless in-app messaging & video calls for feedback. Share performance dashboards and collaborate in real-time.",
    },
    {
      icon: <BarChart2 className="h-12 w-12 text-primary" />,
      title: "Smart Data Visualization & Reporting",
      description:
        "Interactive graphs & AI-powered performance insights. Generate comprehensive reports for athletes, coaches, and medical professionals.",
    },
    {
      icon: <Cloud className="h-12 w-12 text-primary" />,
      title: "Cloud-Based Multi-User Platform",
      description:
        "Secure & centralized storage for all athlete data & reports. Accessible from any device with proper authentication.",
    },
  ]

  return (
    <div className="container py-12">
      <div className="mx-auto max-w-4xl text-center">
        <h1 className="text-4xl font-bold tracking-tight">Features</h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Explore the comprehensive suite of tools VayuVenture offers to enhance athlete performance and well-being
        </p>
      </div>
      <div className="mt-12 grid gap-8 md:grid-cols-2">
        {features.map((feature, index) => (
          <Card key={index}>
            <CardHeader>
              <div className="mb-4">{feature.icon}</div>
              <CardTitle>{feature.title}</CardTitle>
              <CardDescription>{feature.description}</CardDescription>
            </CardHeader>
          </Card>
        ))}
      </div>
    </div>
  )
}

