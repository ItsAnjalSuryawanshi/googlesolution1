import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Activity, Calendar, MessageSquare, FileText, Award, Clock, TrendingUp } from "lucide-react"

export default function AthletePage({ params }: { params: { id: string } }) {
  // This would normally fetch athlete data based on the ID
  const athlete = {
    id: params.id,
    name: "Sarah Johnson",
    sport: "Track & Field",
    specialization: "400m Hurdles",
    age: 23,
    height: "5'9\"",
    weight: "140 lbs",
    team: "National Athletics",
    coach: "Michael Stevens",
    achievements: [
      "Gold Medal - National Championship 2023",
      "Silver Medal - World University Games 2022",
      "Bronze Medal - Continental Cup 2021",
    ],
    upcomingEvents: [
      { name: "Regional Qualifiers", date: "May 15, 2024" },
      { name: "National Championship", date: "June 22, 2024" },
      { name: "International Invitational", date: "July 10, 2024" },
    ],
    recentPerformance: [
      { event: "400m Hurdles", result: "56.78s", date: "March 12, 2024" },
      { event: "400m Flat", result: "53.21s", date: "February 28, 2024" },
      { event: "200m", result: "24.35s", date: "February 15, 2024" },
    ],
  }

  return (
    <div className="container py-10">
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-1">
          <Card>
            <CardHeader className="flex flex-col items-center">
              <Avatar className="h-24 w-24">
                <AvatarImage src="/placeholder.svg?height=96&width=96" alt={athlete.name} />
                <AvatarFallback>
                  {athlete.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <CardTitle className="mt-4 text-center">{athlete.name}</CardTitle>
              <CardDescription className="text-center">
                {athlete.sport} - {athlete.specialization}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="font-medium">Age</div>
                  <div>{athlete.age}</div>
                  <div className="font-medium">Height</div>
                  <div>{athlete.height}</div>
                  <div className="font-medium">Weight</div>
                  <div>{athlete.weight}</div>
                  <div className="font-medium">Team</div>
                  <div>{athlete.team}</div>
                  <div className="font-medium">Coach</div>
                  <div>{athlete.coach}</div>
                </div>
                <div className="flex justify-between pt-4">
                  <Button variant="outline" size="sm">
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Message
                  </Button>
                  <Button variant="outline" size="sm">
                    <FileText className="mr-2 h-4 w-4" />
                    Full Profile
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="text-lg">Achievements</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {athlete.achievements.map((achievement, index) => (
                  <div key={index} className="flex items-start">
                    <Award className="mr-2 h-4 w-4 text-primary mt-0.5" />
                    <span className="text-sm">{achievement}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
        <div className="lg:col-span-2">
          <Tabs defaultValue="performance" className="space-y-4">
            <TabsList className="grid grid-cols-3 w-full">
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="training">Training</TabsTrigger>
              <TabsTrigger value="schedule">Schedule</TabsTrigger>
            </TabsList>
            <TabsContent value="performance" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Performance Metrics</CardTitle>
                  <CardDescription>Track your progress over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] w-full bg-muted rounded-md flex items-center justify-center">
                    <span className="text-muted-foreground">Performance chart will appear here</span>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Recent Results</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {athlete.recentPerformance.map((performance, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Activity className="mr-2 h-4 w-4 text-primary" />
                          <div>
                            <p className="text-sm font-medium">{performance.event}</p>
                            <p className="text-xs text-muted-foreground">{performance.date}</p>
                          </div>
                        </div>
                        <div className="flex items-center">
                          <TrendingUp className="mr-2 h-4 w-4 text-green-500" />
                          <span className="font-medium">{performance.result}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="training" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Training Program</CardTitle>
                  <CardDescription>AI-generated workout plans</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="rounded-md border p-4">
                      <div className="font-medium">Today's Workout</div>
                      <div className="mt-2 space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Warm-up</span>
                          <span>15 minutes</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Speed Intervals</span>
                          <span>8 x 200m</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Hurdle Technique</span>
                          <span>30 minutes</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Strength Training</span>
                          <span>45 minutes</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Cool Down</span>
                          <span>10 minutes</span>
                        </div>
                      </div>
                    </div>
                    <Button className="w-full">View Full Training Plan</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="schedule" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Upcoming Events</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {athlete.upcomingEvents.map((event, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Calendar className="mr-2 h-4 w-4 text-primary" />
                          <div>
                            <p className="text-sm font-medium">{event.name}</p>
                            <p className="text-xs text-muted-foreground">{event.date}</p>
                          </div>
                        </div>
                        <div className="flex items-center">
                          <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
                          <Button variant="outline" size="sm">
                            Details
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

